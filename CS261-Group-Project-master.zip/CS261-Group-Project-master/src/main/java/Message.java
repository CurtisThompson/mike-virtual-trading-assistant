public class Message {
	public String message = "";
	public String origin = "";

	public Message(String message, String origin) {
		this.message = message;
		this.origin = origin;
	}
}
