# src.main.java.LSEScraper
src.main.java.LSEScraper is a web scraper for the the FTSE100 from the london stock exchanage used in the software engineering module.

The rss feed is in the following format: 

- Code
- Name
- Currency
- Price 
- Differnce
- Percentage Difference